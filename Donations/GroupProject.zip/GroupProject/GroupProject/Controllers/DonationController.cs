﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GroupProject.Controllers
{
    public class DonationController : Controller
    {
        // GET: Donation
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Home()
        {
            return View();
        }
        public ActionResult LogIn()
        {
            return View("MakeDonation");
        }
        public ActionResult Registration()
        {
            return View("MakeDonation");
        }
        public ActionResult MakeDonation()
        {
            return View("BankDetails");
        }
        public ActionResult BankDetails()
        {
            return View();
        }
        public ActionResult BankResult()
        {
            //pop up of the result from the bank (successful or not)
            
            return View();
        }
        public ActionResult HowToDonate()
        {
            return View();
        }
        public ActionResult Info()
        {
            return View();
        }
    }
}